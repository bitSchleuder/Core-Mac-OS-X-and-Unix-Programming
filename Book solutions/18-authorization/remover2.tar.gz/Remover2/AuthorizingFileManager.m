//
//  AuthorizingFileManager.m
//  Remover
//
//  Created by Aaron Hillegass on Tue Sep 10 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//

#import "AuthorizingFileManager.h"

static AuthorizingFileManager *_defaultAuthFileManager;

@implementation AuthorizingFileManager


+ (id)defaultManager
{
	if (!_defaultAuthFileManager) {
		_defaultAuthFileManager = [[self alloc] init];
	}
	return _defaultAuthFileManager;
}
- (id)init
{
	[super init];
	fileManager = [NSFileManager defaultManager];
	return self;
}

- (BOOL)removeFileAtPath:(NSString *)path handler:handler
{
	BOOL successful = [fileManager removeFileAtPath:path handler:self];
	if (!successful) {
		// Preauthorize
		// Run deletor
	}
	return YES;
}

- (NSArray *)directoryContentsAtPath:(NSString *)path
{
	NSArray *result;
	result = [fileManager directoryContentsAtPath:path];
	if (!result) {
		// Preauthorize
		// run lister
		// get output
		// put into an autoreleased array
	}
	return result;
}

- (NSDictionary *)fileAttributesAtPath:(NSString *)path traverseLink:(BOOL)willTraverse
{
	NSDictionary *result;
	result = [fileManager fileAttributesAtPath:path traverseLink:willTraverse];
	if (!result) {
		// Preauthorize
		// run statter
		// get output
		// put into an autoreleased dictionary
	}
	return result;
}

- (NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector
{
	NSMethodSignature *result;
	result = [super methodSignatureForSelector:aSelector];
	if (!result){
		result = [fileManager methodSignatureForSelector:aSelector];
	}
	return result;
}

- (void)forwardInvocation:(NSInvocation *)invocation
{
	SEL aSelector = [invocation selector];
	if ([fileManager respondsToSelector:aSelector])
		[invocation invokeWithTarget:fileManager];
	else
		[self doesNotRecognizeSelector:aSelector];
}

@end
