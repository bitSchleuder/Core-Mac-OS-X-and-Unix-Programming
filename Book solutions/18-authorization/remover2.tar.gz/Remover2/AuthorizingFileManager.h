//
//  AuthorizingFileManager.h
//  Remover
//
//  Created by Aaron Hillegass on Tue Sep 10 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface AuthorizingFileManager : NSObject {
	NSFileManager *fileManager;
}

+ (id)defaultManager;
- (id)init;

- (BOOL)removeFileAtPath:(NSString *)path handler:handler;
- (NSArray *)directoryContentsAtPath:(NSString *)path;
- (BOOL)fileExistsAtPath:(NSString *)path isDirectory:(BOOL *)isDirectory;

- (void)forwardInvocation:(NSInvocation *)anInvocation;

@end
