This is an example of authorization.  As such,  it has several little tools that need to run as root (if you have no power,  what good is authorization?)  Thus,  they need their suid bit set and their owner set to root.  The cool way to do this is have them repair themselves.  The stupid way to do this (and they way we will do in this example) is to simply set it from terminal

su
cd Remover/build/Remover.app/Contents/Resources
chmod 6555 remover_lister
chown root remover_lister