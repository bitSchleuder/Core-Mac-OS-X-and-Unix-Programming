//
//  DirEntry.m
//  Remover
//
//  Created by Aaron Hillegass on Sun Sep 08 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//

#import "DirEntry.h"

#define UNSET 3

@implementation DirEntry

+ (NSMutableArray *)entriesAtPath:(NSString *)p withParent:(DirEntry *)d
{
		int max, k;
		DirEntry *newEntry;
		NSFileManager *manager = [NSFileManager defaultManager];
		NSArray *filenames;
		NSMutableArray *result = [NSMutableArray array];
		NSLog(@"reading %@", p);
		filenames = [manager directoryContentsAtPath:p];
		if (filenames == nil) {
			NSLog(@"Unable to read %@", p);
			return result;
		}
		max = [filenames count];
		for (k = 0; k < max; k++) {
			newEntry = [[DirEntry alloc] initWithFilename:[filenames objectAtIndex:k] parent:d];
			[result addObject:newEntry];
			[newEntry release];
		}
		return result;
}

- (id)initWithFilename:(NSString *)fn
							parent:(DirEntry *)p
{
	[super init];
	parent = p;
	filename = [fn copy];
	isDirectory = UNSET;
	return self;
}
- (NSMutableArray *)components
{
	NSMutableArray *result;
	if (!parent) {
		result = [NSMutableArray array];
		[result addObject:@""];
	} else {
		result = [parent components];
	}
	[result addObject:[self filename]];
	return result;
}
		
- (NSString *)fullPath
{
	return [[self components] componentsJoinedByString:@"/"];
}
- (NSString *)filename
{
	return filename;
}
// Could be extended to deal with symlinks right
- (BOOL)isDirectory
{
	// Is this the first time we've been asked?
	if (isDirectory == UNSET) {
		NSString *path = [self fullPath];
		if (![[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDirectory]) {
			NSLog(@"No such file: %@", path);
			isDirectory = NO;
		}
	}
	return isDirectory;
}
- (NSArray *)children
{
	NSString *path = [self fullPath];
	return [DirEntry entriesAtPath:path withParent:self];
}

- (DirEntry *)parent
{
	return parent;
}

- (void)dealloc
{
	[filename release];
	[super dealloc];
}

@end
