This is an example of authorization.  As such,  it has several little tools that need to run as root (if you have no power,  what good is authorization?)  Thus,  they need their suid bit set and their owner set to root.  The cool way to do this is have them repair themselves.  The stupid way to do this (and they way we will do in this example) is to simply set it from terminal

su
cd Remover/build/Remover.app/Contents/Resources
chmod 6555 remover_*
chown root remover_*

Once you've authorized for the right com.bignerdranch.readForbiddenDirectories,  you'll get (by default)
com.bignerdranch.deleteForbiddenDirectories.  If you'd like to change that,  edit /etc/authorization.  For example,  adding this line will allow all users to read the forbidden directories:

   <key>com.bignerdranch.readForbiddenDirectories</key>
         <string>allow</string>
